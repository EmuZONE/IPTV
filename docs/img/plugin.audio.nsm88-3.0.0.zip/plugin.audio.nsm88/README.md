<p align="center"><img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/NSM_Logo_500px.png"></p>
<br>
<br>
Ein Musik Addon für das XB Media Center. Mit diesem Plugin bekommt man Zugriff auf eine riesige RAC Musik Bibliothek welche aktuelle Musik Alben sowie Raritäten aus den verschiedensten Bereichen umfasst. Alle Titel sind in 320 kBits verfügbar.
<br>
<br>
<br>
<b>Latest Changes:</b> 
<br>
<li>Umlaute wurden Korrigiert sowie 15 neue Alben hinzugefügt</li>
<li>Uwocaust & alte Freunde: Blutgruppe</li>
<li>Jan Peter: Echoes from the Past</li>
<li>Ian Stuart: No Turning Back</li>
<li>Ian Stuart: Slay the Beast</li>
<br>
<br>
<h3>Screens:</h3>
<br>
<p align="center"><img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_01.png"> <img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_02.png"> <img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_03.png"></p>
